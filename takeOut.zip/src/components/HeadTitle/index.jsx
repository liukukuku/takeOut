import React from "react";
import "./style.less";
function Index(props) {
  const { val } = props;
  return (
    <div className="HeadTitle">
      <div className="Headlef">放大镜</div>
      <div className="Headmid">{val}</div>
      <div className="Headrig">奥利给</div>
    </div>
  );
}

export default Index;
