export default {
  homePages: 'https://elm.cangdu.org/v1/cities', //city
  GetentryUrl: "https://elm.cangdu.org/v2/index_entry",//获取食品分类列表
  Getrestaurantsurl: "https://elm.cangdu.org/shopping/restaurants",//获取商铺列表
  SearchMes: "https://elm.cangdu.org/v1/cities", //获取所选城市信息
  SearchAddress: "https://elm.cangdu.org/v1/pois",
  loginyz: "/xxx/v1/captchas", //获取验证码
  login: "/xxx/v2/login", //登陆
}

